from urllib import request, parse
from fake_useragent import UserAgent
import re
import pymysql

url = 'https://maoyan.com/board/4?offset=0'

headers = {
    "User-Agent": UserAgent().random
}


def request_url(start_page, end_page):
    for page in range(start_page, end_page + 1):
        parses = {
            'offset': (page - 1) * 10,
        }
        result = parse.urlencode(parses)
        url = "https://maoyan.com/board/4?" + result
        req = request.Request(url, headers=headers)
        response = request.urlopen(url)
        html = response.read().decode("utf-8")
        pipei(html)


def pipei(html):
    pattern = re.compile(
        '<dd>.*?>(.*?)</i>.*?<img.*?<img.*?data-src="(.*?)".*?alt="(.*?)".*?star">(.*?)<.*?releasetime">(.*?)<.*?integer">(.*?)<.*?fraction">(.*?)<',
        re.S)
    data = re.findall(pattern, html)


def link_mysql(data):
    # 连接数据库
    db = pymysql.connect(host="localhost",user="root", db="data", password="abcd1234",port=3306)
    cursor = db.cursor()
    sql = "INSERT INTO maoyan(data) VALUES(%s)",data
    cursor.execute(sql)
    db.commit()
    cursor.close()
    db.close()


if __name__ == '__main__':
    start_page = int(input('输入起始页：'))
    end_page = int(input('输入截止页：'))
    request_url(start_page, end_page)
